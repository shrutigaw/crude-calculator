package com.edu.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/calculator")
public class CalculatorController {

    @GetMapping("/calculate")
    public ResponseEntity<Double> calculate(
            @RequestParam double num1,
            @RequestParam double num2,
            @RequestParam String operation) {
        double result;
        switch (operation.toUpperCase()) {
            case "ADD": result = num1 + num2; break;
            case "SUBSTRACT": result = num1 - num2; break;
            case "MULTIPLY": result = num1 * num2; break;
            case "DIVISION":
                if (num2 == 0) {
                    return ResponseEntity.badRequest().body(null);
                }
                result = num1 / num2;
                break;
            default:
                return ResponseEntity.badRequest().body(null);
        }
        return ResponseEntity.ok(result);
    }
}

