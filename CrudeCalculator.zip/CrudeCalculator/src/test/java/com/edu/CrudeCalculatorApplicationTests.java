package com.edu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudeCalculatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
